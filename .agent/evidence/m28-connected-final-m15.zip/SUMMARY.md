# Orbit M15 automated acceptance

Profile: full

| Check | Status |
|---|---|
| python-version | passed |
| user-documentation-contract | passed |
| release-workflow-contract | failed |
| github-installer-contract | passed |
| installer-contract | passed |
| installer-transaction-contract | passed |
| installation-environment-contract | passed |
| installation-manifest-safety | passed |
| release-archive-contract | passed |
| release-installation-contract | passed |
| optional-worker-installer-contract | passed |
| server-setup-contract | passed |
| rust-toolchain | passed |
| cargo-version | passed |
| cargo-metadata | passed |
| cargo-format | passed |
| cargo-check | passed |
| cargo-test | passed |
| python-worker-tests | passed |
| python-contract-tests | failed |
| m25-blueprint-contracts | passed |
| m25-blueprint-crate-tests | passed |
| m25-blueprint-cli-tests | passed |
| cargo-clippy | passed |
| cargo-build | passed |
| agent-scenario-c | passed |
| connected-attachments | passed |
| connected-tui | passed |
| mcp-external-agent | passed |
| connected-mcp | passed |
| local-cli-persistence-smoke | passed |
| real-release-archive-smoke | passed |
| m25-blueprint-cli-help | passed |
| m27-init-doctor-acceptance | passed |
| m27-docs-cli-help | passed |
| m27-update-acceptance | passed |
| m25-validate-development | passed |
| m25-validate-learning | passed |
| m25-validate-habits | passed |
| m25-validate-research | passed |
| server-task-smoke | passed |
| server-domain-smoke | passed |
| local-authority-smoke | passed |
| server-durability-smoke | passed |
| offline-authority-smoke | passed |
| blueprint-workflow-smoke | passed |
| agent-execution-contract | passed |

Counts: {"passed": 45, "failed": 2, "timeout": 0, "error": 0, "not_run": 0}

Exit 0: complete pass; 1: failure; 2: incomplete (required check skipped).
Live Herdr, production deployment, and destructive migration drills are not automatically run.
Blueprint manifest inventory checks do not substitute for compiled Rust blueprint tests.
Documentation and packaging checks validate repository artifacts only; they do not install software system-wide.
The local CLI persistence smoke uses the compiled target/debug/orbit binary against disposable local data.
The agent-scenario-c check uses a scripted Herdr CLI and proves Orbit-side lifecycle state only, not live Herdr or model behaviour.
The connected-attachments check proves loopback server attachment import/list/download/remove against disposable replicas, including pending upload, flush and metadata-only ledger payload; it does not prove a production deployment.
The connected-tui check drives the real TUI against a disposable authoritative server, proving pending -> flush -> accepted behavior without a production deployment.
The connected-mcp check drives the real orbit-mcp binary over stdio against a disposable authoritative server and replica, proving connected rich-task reads, pending -> flush mutations and read-only denial; it does not create an agent job or prove a live model/Herdr.
The mcp-external-agent check drives the real orbit-mcp binary over stdio and inspects the same workspace in the real TUI; it does not prove a live model, Herdr or remote MCP transport.
All HTTP smoke tests target temporary loopback servers and disposable databases.
