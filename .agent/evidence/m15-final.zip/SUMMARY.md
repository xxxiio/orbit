# Orbit M15 automated acceptance

Profile: full

| Check | Status |
|---|---|
| python-version | passed |
| user-documentation-contract | passed |
| installer-contract | passed |
| installer-transaction-contract | passed |
| installation-environment-contract | passed |
| installation-manifest-safety | passed |
| release-archive-contract | passed |
| release-installation-contract | passed |
| optional-worker-installer-contract | passed |
| server-setup-contract | passed |
| rust-toolchain | passed |
| cargo-version | passed |
| cargo-metadata | passed |
| cargo-format | passed |
| cargo-check | passed |
| cargo-test | passed |
| python-worker-tests | passed |
| python-contract-tests | passed |
| m25-blueprint-contracts | passed |
| m25-blueprint-crate-tests | passed |
| m25-blueprint-cli-tests | passed |
| cargo-clippy | passed |
| cargo-build | passed |
| local-cli-persistence-smoke | passed |
| real-release-archive-smoke | passed |
| m25-blueprint-cli-help | passed |
| m25-validate-development | passed |
| m25-validate-learning | passed |
| m25-validate-habits | passed |
| m25-validate-research | passed |
| server-task-smoke | passed |
| server-domain-smoke | passed |
| local-authority-smoke | passed |
| server-durability-smoke | passed |
| offline-authority-smoke | passed |
| blueprint-workflow-smoke | passed |
| agent-execution-contract | passed |
| herdr-live-acceptance | passed |

Counts: {"passed": 38, "failed": 0, "timeout": 0, "error": 0, "not_run": 0}

Exit 0: complete pass; 1: failure; 2: incomplete (required check skipped).
Live Herdr, production deployment, and destructive migration drills are not automatically run.
Blueprint manifest inventory checks do not substitute for compiled Rust blueprint tests.
Documentation and packaging checks validate repository artifacts only; they do not install software system-wide.
The local CLI persistence smoke uses the compiled target/debug/orbit binary against disposable local data.
All HTTP smoke tests target temporary loopback servers and disposable databases.
